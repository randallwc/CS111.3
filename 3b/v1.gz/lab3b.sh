#!/bin/bash
#run python script with arguments from the bash script
python3 lab3b.py "$@"
#return exit status of python script
exit $?